import * as React from 'react';

const Loader: React.StatelessComponent<{}> = () => (
  <div className='CommitPanel-details-loader'></div>
);

export default Loader;
